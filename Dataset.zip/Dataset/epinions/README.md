INTERACTIONs DATASET FILE DESCRIPTION
------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
The file epinions.inter comprising the ratings and prices of users over the goods.
Each record/line in the file has the following fields: user_id, item_id, rating, timestamp, price

user_id: the id of the users and its type is token. 
item_id: the id of the goods and its type is token.
rating: the rating of the users over the goods, and its type is float.
timestamp: the UNIX timestamp of the records, and its type is float.
price: the price of the good that this user has bought, and its type is float.
